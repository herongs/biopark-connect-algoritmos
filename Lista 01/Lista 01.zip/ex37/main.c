#include <stdio.h>
#include <stdlib.h>

//Fa�a um algoritmo que calcule e mostre a tabuada de um n�mero digitado pelo usu�rio.

int main()
{
    float numero;

    printf("Qual e o numero? \n");
    scanf("%f", &numero);

    printf("%.2f\n", numero*1);
    printf("%.2f\n", numero*2);
    printf("%.2f\n", numero*3);
    printf("%.2f\n", numero*4);
    printf("%.2f\n", numero*5);
    printf("%.2f\n", numero*6);
    printf("%.2f\n", numero*7);
    printf("%.2f\n", numero*8);
    printf("%.2f\n", numero*9);
    printf("%.2f\n", numero*10);
}
